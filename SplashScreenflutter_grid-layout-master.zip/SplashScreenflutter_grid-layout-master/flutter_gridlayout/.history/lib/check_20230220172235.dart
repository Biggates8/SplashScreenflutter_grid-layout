import 'package:flutter/material.dart';
import 'package:fluttertoast/flutter.dart';

void main() => runApp(MaterialApp(home: GridLayout()));

class GridLayout extends StatelessWidget {
  GridLayout({super.key});

  List<String> events = [
    "ambulance",
    "air ambulance",
    "medical supplies",
    "pharmacy",
    "e-hailing",
    "hospital, clinics and doctors",
    "food delivery"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
          image: AssetImage("assets/air ambulance.png"),
        )),
      ),
    );
  }
}
