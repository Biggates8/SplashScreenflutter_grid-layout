import 'package:flutter/material.dart';
import 'package:flutter_gridlayout/views/check.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Check',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        appBarTheme: const AppBarTheme(
          titleSpacing: 0,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: Colors.red,
            fontWeight: FontWeight.w600,
            fontSize: 23,
          ),
          color: Colors.red,
        ),
        scaffoldBackgroundColor: Colors.red,
        fontFamily: GoogleFonts.lato().fontFamily,
        primarySwatch: Colors.blue,
      ),
      home: GridLayout(),
    );
  }
}
