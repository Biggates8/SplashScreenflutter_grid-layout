import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main() => runApp(MaterialApp(home: GridLayout()));

class GridLayout extends StatelessWidget {
  GridLayout({super.key});

  List<String> events = [
    "ambulance",
    "air ambulance",
    "medical supplies",
    "pharmacy",
    "e-hailing",
    "hospital, clinics and doctors",
    "food delivery"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/air ambulance.png"),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          margin: const EdgeInsets.only(top: 120.0),
          child: GridView(
              physics: BouncingScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
              ),
              children: events.map((title) {
                return GestureDetector(
                  child: Card(
                    elevation: 0,
                    color: Colors.transparent,
                    margin: const EdgeInsets.all(13.0),
                    child: getCardByTitle(title),
                  ),
                  onTap: () {
                    Fluttertoast.showToast(
                        msg: title + " click",
                        toastLength: Toast.LENGTH_SHORT,
                        gravity: ToastGravity.CENTER,
                        backgroundColor: Colors.red,
                        textColor: Colors.white,
                        fontSize: 16.0);
                  },
                );
              }).toList()),
        ),
      ),
    );
  }
}
