package com.example.flutter_gridlayout

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
